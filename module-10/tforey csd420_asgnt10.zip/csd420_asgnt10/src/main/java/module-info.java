module com.mycompany.csd420_asgnt10 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    exports com.mycompany.csd420_asgnt10;
}
