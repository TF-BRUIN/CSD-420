package com.mycompany.csd420_asgnt07;

import java.io.IOException;
import javafx.fxml.FXML;

public class PrimaryController {

    @FXML
    private void switchToSecondary() throws IOException {
        csd420_asgnt07.setRoot("secondary");
    }
}
