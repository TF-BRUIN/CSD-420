module com.mycompany.csd420_asgnt07 {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.mycompany.csd420_asgnt07 to javafx.fxml;
    exports com.mycompany.csd420_asgnt07;
}
