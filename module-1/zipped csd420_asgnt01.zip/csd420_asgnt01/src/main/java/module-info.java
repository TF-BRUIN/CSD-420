module com.mycompany.csd420_asgnt01 {
    requires javafx.controls;
    exports com.mycompany.csd420_asgnt01;
}
